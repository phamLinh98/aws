import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";

// Tên secret
const secret_name = "TestEnvKey";

// Tạo client SecretsManager
const client = new SecretsManagerClient({
  region: "ap-northeast-1",
});

export const handler = async (event) => {
  let secret;

  try {
    // Lấy giá trị secret
    const response = await client.send(
      new GetSecretValueCommand({
        SecretId: secret_name,
        VersionStage: "AWSCURRENT",
      })
    );

    if ("SecretString" in response) {
      secret = response.SecretString;
    } else {
      const buff = Buffer.from(response.SecretBinary, "base64");
      secret = buff.toString("ascii");
    }

    // Parse JSON string để lấy KEY
    const parsedSecret = JSON.parse(secret);
    const keyValue = parsedSecret["API-KEY"];
    
    console.log("Secret:", secret);
    console.log("Parsed Secret:", parsedSecret);
    console.log("Secret KEY:", keyValue);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Secret KEY fetched successfully",
        key: keyValue,
      }),
    };
  } catch (error) {
    console.error("Error fetching secret:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to retrieve secret",
        error: error.message,
      }),
    };
  }
};